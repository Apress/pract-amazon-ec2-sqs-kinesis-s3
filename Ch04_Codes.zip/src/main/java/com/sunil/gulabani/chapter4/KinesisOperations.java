package com.sunil.gulabani.chapter4;

import com.amazonaws.services.kinesis.AmazonKinesisClient;
import com.amazonaws.services.kinesis.model.*;
import com.amazonaws.util.StringUtils;
import com.sunil.gulabani.chapter4.core.AWSClientInitializer;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class KinesisOperations extends AWSClientInitializer {

    protected AmazonKinesisClient amazonKinesisClient;
    private String awsUserAccountId;

    public KinesisOperations (String awsUserAccountId) {
        super();
        if(!StringUtils.isNullOrEmpty(getClientConfiguration().getProxyHost())) {
            amazonKinesisClient = new AmazonKinesisClient(getCredentials(), getClientConfiguration());
        } else {
            amazonKinesisClient = new AmazonKinesisClient(getCredentials());
        }
        amazonKinesisClient.setRegion(region);
        this.awsUserAccountId = awsUserAccountId;
    }

    public void createStream(String streamName, Integer shardCount) {
        seperator("createStream");
//        CreateStreamResult response = amazonKinesisClient.createStream(streamName, shardCount);

        CreateStreamRequest request = new CreateStreamRequest();
        request.setStreamName(streamName);
        request.setShardCount(shardCount);
        CreateStreamResult response = amazonKinesisClient.createStream(request);

        printObject(response, "createStream");
    }

    public DescribeStreamResult describeStream(String streamName, Integer limit, String exclusiveStartShardId) {

//      DescribeStreamResult response = amazonKinesisClient.describeStream(streamName);

        DescribeStreamRequest request = new DescribeStreamRequest();
        request.setStreamName(streamName);

        if(limit != null) {
            request.setLimit(limit);
        }

        if(!StringUtils.isNullOrEmpty(exclusiveStartShardId)) {
            request.setExclusiveStartShardId(exclusiveStartShardId);
        }

        DescribeStreamResult response = amazonKinesisClient.describeStream(request);

        printObject(response, "describeStream");
        return response;
    }

    public void listStreams(String exclusiveStartStreamName, Integer streamListingLimit) {
//        ListStreamsResult response = amazonKinesisClient.listStreams();

        ListStreamsRequest request = new ListStreamsRequest();

        if(!StringUtils.isNullOrEmpty(exclusiveStartStreamName)) {
            request.setExclusiveStartStreamName(exclusiveStartStreamName);
        }

        if(streamListingLimit != null) {
            request.setLimit(streamListingLimit);
        }

        ListStreamsResult response = amazonKinesisClient.listStreams(request);

        printObject(response, "listStreams");
    }

    public void deleteStream(String streamName) {
//        DeleteStreamResult response = amazonKinesisClient.deleteStream(streamName);

        DeleteStreamRequest request = new DeleteStreamRequest();
        request.setStreamName(streamName);
        DeleteStreamResult response = amazonKinesisClient.deleteStream(request);
        printObject(response, "deleteStream");
    }

    public void increaseStreamRetentionPeriod(String streamName, Integer retentionPeriodHours) {
        IncreaseStreamRetentionPeriodRequest request = new IncreaseStreamRetentionPeriodRequest();
        request.setStreamName(streamName);
        request.setRetentionPeriodHours(retentionPeriodHours);
        IncreaseStreamRetentionPeriodResult response = amazonKinesisClient.increaseStreamRetentionPeriod(request);
        printObject(response, "increaseStreamRetentionPeriod");
    }

    public void decreaseStreamRetentionPeriod(String streamName, Integer retentionPeriodHours) {
        DecreaseStreamRetentionPeriodRequest request = new DecreaseStreamRetentionPeriodRequest();
        request.setStreamName(streamName);
        request.setRetentionPeriodHours(retentionPeriodHours);
        DecreaseStreamRetentionPeriodResult response = amazonKinesisClient.decreaseStreamRetentionPeriod(request);
        printObject(response, "decreaseStreamRetentionPeriod");
    }

    public void putRecord(String streamName, String partitionKey, byte[] data, String explicitHashKey) {
//        PutRecordResult response = amazonKinesisClient.putRecord(streamName, ByteBuffer.wrap(data), partitionKey);

        PutRecordRequest request = new PutRecordRequest();
        request.setStreamName(streamName);
        request.setPartitionKey(partitionKey);
        request.setData(ByteBuffer.wrap(data));

        if(!StringUtils.isNullOrEmpty(explicitHashKey)) {
            request.setExplicitHashKey(explicitHashKey);
        }

        PutRecordResult response = amazonKinesisClient.putRecord(request);

        printObject(response, "putRecord");
    }

    public PutRecordsRequestEntry createPutRecordsRequestEntry(String partitionKey, String data, String exclusiveHashKey) {
        PutRecordsRequestEntry requestEntry = new PutRecordsRequestEntry();
        requestEntry.setPartitionKey(partitionKey);
        requestEntry.setData(ByteBuffer.wrap(data.getBytes()));

        if(!StringUtils.isNullOrEmpty(exclusiveHashKey)) {
            requestEntry.setExplicitHashKey(exclusiveHashKey);
        }

        return requestEntry;
    }

    public void putRecords(String streamName, List<PutRecordsRequestEntry> records) {
        PutRecordsRequest request = new PutRecordsRequest();
        request.setStreamName(streamName);
        request.setRecords(records);
        PutRecordsResult response = amazonKinesisClient.putRecords(request);
        printObject(response, "putRecords");
    }

    public void getRecords(String streamName) throws UnsupportedEncodingException {
        GetRecordsRequest request = new GetRecordsRequest();

        request.setLimit(100);

        List<String> shardIterators = getShardIterators(streamName, ShardIteratorType.TRIM_HORIZON);

        List<GetRecordsResult> response = new ArrayList<GetRecordsResult>();
        shardIterators.forEach(shardIterator -> {
            request.setShardIterator(shardIterator);
            GetRecordsResult getRecordsResult = amazonKinesisClient.getRecords(request);
            response.add(getRecordsResult);
        });
        printObject(response, "getRecords");

        System.out.println("-------------");
        for(GetRecordsResult result: response) {
            for(Record record: result.getRecords()) {
                String data = new String(record.getData().array(), "UTF-8");
                System.out.println(data);
            }
        }
    }

    private List<String> getShardIterators(String streamName, ShardIteratorType shardIteratorType) {
        List<String> shardIteratorList = new ArrayList<>();
        List<Shard> shardList = getShards(streamName);
        shardList.forEach(shard -> {
            GetShardIteratorResult shardIteratorResult = getShardIteratorResult(streamName, shardIteratorType, shard);
            printObject(shardIteratorResult, "shardIteratorResult-" + shard.getShardId());
            shardIteratorList.add(shardIteratorResult.getShardIterator());
        });
        return shardIteratorList;
    }

    private GetShardIteratorResult getShardIteratorResult(String streamName, ShardIteratorType shardIteratorType, Shard shard) {
//        return shardIteratorResult = amazonKinesisClient.getShardIterator(streamName, shard.getShardId(), shardIteratorType.toString());
        GetShardIteratorRequest shardIteratorRequest = new GetShardIteratorRequest();
        shardIteratorRequest.setShardId(shard.getShardId());
        shardIteratorRequest.setShardIteratorType(shardIteratorType);
        shardIteratorRequest.setStreamName(streamName);

        return amazonKinesisClient.getShardIterator(shardIteratorRequest);
    }

    public List<Shard> getShards(String streamName) {
        DescribeStreamResult describeStreamResult = describeStream(streamName, null, null);
        return describeStreamResult.getStreamDescription().getShards();
    }

    public void mergeShards(String streamName, String shardIdToMerger, String adjacentShardIdToMerge) {
//        MergeShardsResult response = amazonKinesisClient.mergeShards(streamName, shardIdToMerger, adjacentShardIdToMerge);

        MergeShardsRequest request = new MergeShardsRequest();
        request.setStreamName(streamName);
        request.setShardToMerge(shardIdToMerger);
        request.setAdjacentShardToMerge(adjacentShardIdToMerge);
        MergeShardsResult response = amazonKinesisClient.mergeShards(request);
        printObject(response, "mergeShards");
    }

    public void splitShard(String streamName, Shard shard) {
        SplitShardRequest request = new SplitShardRequest();
        request.setStreamName(streamName);
        request.setShardToSplit(shard.getShardId());

        String startHashKey = shard.getHashKeyRange().getStartingHashKey();
        String endHashKey   = shard.getHashKeyRange().getEndingHashKey();
        BigInteger tempHashKey = new BigInteger(startHashKey).add(new BigInteger(endHashKey));
        String childHashKey = tempHashKey.divide(new BigInteger("2")).toString();

        request.setNewStartingHashKey(childHashKey);
        SplitShardResult response = amazonKinesisClient.splitShard(request);
        printObject(response, "splitShard");
    }

    public void disableEnhancedMonitoring(String streamName) {
        DisableEnhancedMonitoringRequest request = new DisableEnhancedMonitoringRequest();
        request.setStreamName(streamName);
        request.setShardLevelMetrics(getShardLevelMetrics());
        DisableEnhancedMonitoringResult response = amazonKinesisClient.disableEnhancedMonitoring(request);
        printObject(response, "disableEnhancedMonitoring");
    }

    public void enableEnhancedMonitoring(String streamName) {
        EnableEnhancedMonitoringRequest request = new EnableEnhancedMonitoringRequest();
        request.setStreamName(streamName);
        request.setShardLevelMetrics(getShardLevelMetrics());
        EnableEnhancedMonitoringResult response = amazonKinesisClient.enableEnhancedMonitoring(request);
        printObject(response, "enableEnhancedMonitoring");
    }

    private List<String> getShardLevelMetrics() {

        List<String> shardLevelMetrics = new ArrayList<>();
//        shardLevelMetrics.add("ALL");
        shardLevelMetrics.add("IncomingBytes");
        shardLevelMetrics.add("IncomingRecords");
        shardLevelMetrics.add("OutgoingBytes");
        shardLevelMetrics.add("OutgoingRecords");
        shardLevelMetrics.add("WriteProvisionedThroughputExceeded");
        shardLevelMetrics.add("ReadProvisionedThroughputExceeded");
        shardLevelMetrics.add("IteratorAgeMilliseconds");
        return shardLevelMetrics;
    }

    public void addTagsToStream(String streamName, Map<String, String> tags) {
        AddTagsToStreamRequest request = new AddTagsToStreamRequest();
        request.setStreamName(streamName);
        request.setTags(tags);
        AddTagsToStreamResult response = amazonKinesisClient.addTagsToStream(request);
        printObject(response, "addTagsToStream");
    }

    public void listTagsForStream(String streamName) {
        ListTagsForStreamRequest request = new ListTagsForStreamRequest();
        request.setStreamName(streamName);
        ListTagsForStreamResult response = amazonKinesisClient.listTagsForStream(request);
        printObject(response, "listTagsForStream");
    }

    public void removeTagsFromStream(String streamName, List<String> tagKeys) {
        RemoveTagsFromStreamRequest request = new RemoveTagsFromStreamRequest();
        request.setStreamName(streamName);
        request.setTagKeys(tagKeys);
        RemoveTagsFromStreamResult response = amazonKinesisClient.removeTagsFromStream(request);
        printObject(response, "removeTagsFromStream");
    }
}
