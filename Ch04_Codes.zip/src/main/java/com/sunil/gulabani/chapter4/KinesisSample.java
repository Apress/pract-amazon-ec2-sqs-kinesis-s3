package com.sunil.gulabani.chapter4;

import com.amazonaws.services.kinesis.model.DescribeStreamResult;
import com.amazonaws.services.kinesis.model.PutRecordsRequestEntry;
import com.amazonaws.services.kinesis.model.Shard;
import com.amazonaws.services.kinesis.model.StreamDescription;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class KinesisSample {
    private static final String AWS_ACCOUNT_ID = "AWS_ACCOUNT_ID";
    private static final String STREAM_NAME = "Chapter4KinesisStream";
    private static final Integer SHARD_COUNT = 5;
    private static final Integer SLEEP_TIME_MS = 30000;

    public static void main(String[] args) throws InterruptedException, UnsupportedEncodingException {
        KinesisOperations kinesisOperations = new KinesisOperations(AWS_ACCOUNT_ID);

        kinesisOperations.createStream(STREAM_NAME, SHARD_COUNT);
        Thread.sleep(SLEEP_TIME_MS);
        kinesisOperations.createStream(STREAM_NAME + "1", 1);
        Thread.sleep(SLEEP_TIME_MS);
        kinesisOperations.createStream(STREAM_NAME + "2", 1);
        Thread.sleep(SLEEP_TIME_MS);
        kinesisOperations.createStream(STREAM_NAME + "3", 1);
        Thread.sleep(SLEEP_TIME_MS);
        kinesisOperations.createStream(STREAM_NAME + "4", 1);
        Thread.sleep(SLEEP_TIME_MS);
        kinesisOperations.createStream(STREAM_NAME + "5", 1);
        Thread.sleep(SLEEP_TIME_MS);

        Integer shardListingLimit = null;
        String exclusiveStartShardId = null;
        kinesisOperations.describeStream(STREAM_NAME, shardListingLimit, exclusiveStartShardId);

        shardListingLimit = 1;
        DescribeStreamResult describeStreamResult = kinesisOperations.describeStream(STREAM_NAME, shardListingLimit, exclusiveStartShardId);
        StreamDescription streamDescription = describeStreamResult.getStreamDescription();
        List<Shard> shards = streamDescription.getShards();
        boolean hasMoreShards = streamDescription.getHasMoreShards();
        while(hasMoreShards) {
            exclusiveStartShardId = shards.get(shards.size()-1).getShardId();
            describeStreamResult = kinesisOperations.describeStream(STREAM_NAME, shardListingLimit, exclusiveStartShardId);
            streamDescription = describeStreamResult.getStreamDescription();
            shards = streamDescription.getShards();
            hasMoreShards = streamDescription.getHasMoreShards();
        }

        Integer streamListingLimit = null;
        String exclusiveStartStreamName = null;
        kinesisOperations.listStreams(exclusiveStartStreamName, streamListingLimit);

        streamListingLimit = 1;
        exclusiveStartStreamName = "Chapter4KinesisStream";
        kinesisOperations.listStreams(exclusiveStartStreamName, streamListingLimit);

        kinesisOperations.increaseStreamRetentionPeriod(STREAM_NAME, 72);
        Thread.sleep(SLEEP_TIME_MS);
        kinesisOperations.describeStream(STREAM_NAME, 1, null);

        kinesisOperations.decreaseStreamRetentionPeriod(STREAM_NAME, 24);
        Thread.sleep(SLEEP_TIME_MS);
        kinesisOperations.describeStream(STREAM_NAME, 1, null);


        kinesisOperations.enableEnhancedMonitoring(STREAM_NAME);

        Thread.sleep(SLEEP_TIME_MS);

        kinesisOperations.disableEnhancedMonitoring(STREAM_NAME);
        Thread.sleep(SLEEP_TIME_MS);

        String explicitHashKey = null;
        String partitionKey = "123";
        String data = "Hello World Kinesis!!!";

        kinesisOperations.putRecord(STREAM_NAME, partitionKey, data.getBytes(), explicitHashKey);

        explicitHashKey = "272225893536750770770699685945414569165";
        kinesisOperations.putRecord(STREAM_NAME, partitionKey, data.getBytes(), explicitHashKey);

        List<PutRecordsRequestEntry> records = new ArrayList<>();
        PutRecordsRequestEntry record = null;
        explicitHashKey = null;
        for(int i=0;i<5;i++) {
            record = kinesisOperations.createPutRecordsRequestEntry(String.valueOf(i), data + "-" + i, explicitHashKey);
            records.add(record);
        }

        explicitHashKey = "272225893536750770770699685945414569165";
        record = kinesisOperations.createPutRecordsRequestEntry(String.valueOf(5), data + "-" + 5, explicitHashKey);
        records.add(record);

        kinesisOperations.putRecords(STREAM_NAME, records);


        kinesisOperations.getRecords(STREAM_NAME);


        List<Shard> shardList = kinesisOperations.getShards(STREAM_NAME);
        kinesisOperations.mergeShards(STREAM_NAME, shardList.get(3).getShardId(), shardList.get(4).getShardId());
        Thread.sleep(SLEEP_TIME_MS);
        kinesisOperations.describeStream(STREAM_NAME, null, null);

        shardList = kinesisOperations.getShards(STREAM_NAME);
        kinesisOperations.splitShard(STREAM_NAME, shardList.get(0));
        Thread.sleep(SLEEP_TIME_MS);
        kinesisOperations.describeStream(STREAM_NAME, null, null);

        Map<String, String> tags = new HashMap<>();
        tags.put("Environment", "Production");
        tags.put("Chapter", "4");
        kinesisOperations.addTagsToStream(STREAM_NAME, tags);
        Thread.sleep(SLEEP_TIME_MS);

        kinesisOperations.listTagsForStream(STREAM_NAME);

        List<String> tagKeys = new ArrayList<>();
        tagKeys.add("Environment");
        kinesisOperations.removeTagsFromStream(STREAM_NAME, tagKeys);

        Thread.sleep(SLEEP_TIME_MS);

        kinesisOperations.listTagsForStream(STREAM_NAME);

        kinesisOperations.deleteStream(STREAM_NAME);

        kinesisOperations.listStreams(null, null);
        kinesisOperations.deleteStream(STREAM_NAME + "1");
        kinesisOperations.deleteStream(STREAM_NAME + "2");
        kinesisOperations.deleteStream(STREAM_NAME + "3");
        kinesisOperations.deleteStream(STREAM_NAME + "4");
        kinesisOperations.deleteStream(STREAM_NAME + "5");
        Thread.sleep(SLEEP_TIME_MS);

        kinesisOperations.listStreams(null, null);
    }
}
