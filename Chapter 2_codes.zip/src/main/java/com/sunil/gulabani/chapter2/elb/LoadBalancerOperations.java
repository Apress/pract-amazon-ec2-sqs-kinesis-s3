package com.sunil.gulabani.chapter2.elb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.elasticloadbalancing.AmazonElasticLoadBalancingClient;
import com.amazonaws.services.elasticloadbalancing.model.AddTagsRequest;
import com.amazonaws.services.elasticloadbalancing.model.AddTagsResult;
import com.amazonaws.services.elasticloadbalancing.model.ApplySecurityGroupsToLoadBalancerRequest;
import com.amazonaws.services.elasticloadbalancing.model.ApplySecurityGroupsToLoadBalancerResult;
import com.amazonaws.services.elasticloadbalancing.model.ConfigureHealthCheckRequest;
import com.amazonaws.services.elasticloadbalancing.model.ConfigureHealthCheckResult;
import com.amazonaws.services.elasticloadbalancing.model.CreateLoadBalancerListenersRequest;
import com.amazonaws.services.elasticloadbalancing.model.CreateLoadBalancerListenersResult;
import com.amazonaws.services.elasticloadbalancing.model.CreateLoadBalancerRequest;
import com.amazonaws.services.elasticloadbalancing.model.CreateLoadBalancerResult;
import com.amazonaws.services.elasticloadbalancing.model.DeleteLoadBalancerListenersRequest;
import com.amazonaws.services.elasticloadbalancing.model.DeleteLoadBalancerListenersResult;
import com.amazonaws.services.elasticloadbalancing.model.DeleteLoadBalancerRequest;
import com.amazonaws.services.elasticloadbalancing.model.DeleteLoadBalancerResult;
import com.amazonaws.services.elasticloadbalancing.model.DeregisterInstancesFromLoadBalancerRequest;
import com.amazonaws.services.elasticloadbalancing.model.DeregisterInstancesFromLoadBalancerResult;
import com.amazonaws.services.elasticloadbalancing.model.DescribeInstanceHealthRequest;
import com.amazonaws.services.elasticloadbalancing.model.DescribeInstanceHealthResult;
import com.amazonaws.services.elasticloadbalancing.model.DescribeLoadBalancersRequest;
import com.amazonaws.services.elasticloadbalancing.model.DescribeLoadBalancersResult;
import com.amazonaws.services.elasticloadbalancing.model.DescribeTagsRequest;
import com.amazonaws.services.elasticloadbalancing.model.DescribeTagsResult;
import com.amazonaws.services.elasticloadbalancing.model.HealthCheck;
import com.amazonaws.services.elasticloadbalancing.model.Instance;
import com.amazonaws.services.elasticloadbalancing.model.InstanceState;
import com.amazonaws.services.elasticloadbalancing.model.Listener;
import com.amazonaws.services.elasticloadbalancing.model.ListenerDescription;
import com.amazonaws.services.elasticloadbalancing.model.LoadBalancerDescription;
import com.amazonaws.services.elasticloadbalancing.model.RegisterInstancesWithLoadBalancerRequest;
import com.amazonaws.services.elasticloadbalancing.model.RegisterInstancesWithLoadBalancerResult;
import com.amazonaws.services.elasticloadbalancing.model.RemoveTagsRequest;
import com.amazonaws.services.elasticloadbalancing.model.RemoveTagsResult;
import com.amazonaws.services.elasticloadbalancing.model.Tag;
import com.amazonaws.services.elasticloadbalancing.model.TagDescription;
import com.amazonaws.services.elasticloadbalancing.model.TagKeyOnly;
import com.amazonaws.util.StringUtils;
import com.sunil.gulabani.chapter2.core.AWSClientInitializer;

public class LoadBalancerOperations extends AWSClientInitializer {
	
	private AmazonElasticLoadBalancingClient elbClient;
	
	public LoadBalancerOperations() {
		super();
		elbClient = new AmazonElasticLoadBalancingClient(getCredentials(), getClientConfiguration());
		elbClient.setRegion(region);
	}
	
	public void createLoadBalancer(String loadBalancerName, List<String> securityGroups) {
		CreateLoadBalancerRequest request = new CreateLoadBalancerRequest();
		request.setLoadBalancerName(loadBalancerName);
		List<Listener> listeners = new ArrayList<Listener>();
        listeners.add(new Listener("HTTP", 80, 80));
        listeners.add(new Listener("HTTPS", 443, 443));
//        request.withAvailabilityZones(availabilityZone1,availabilityZone2);
        request.setListeners(listeners);
        
        request.setSecurityGroups(securityGroups);
        
        CreateLoadBalancerResult response = elbClient.createLoadBalancer(request);
        
        printObject(response);
	}
	
	public void applySecurityGroupsToLoadBalancer(String loadBalancerName, List<String> securityGroups) {
		ApplySecurityGroupsToLoadBalancerRequest request = new ApplySecurityGroupsToLoadBalancerRequest();
		request.setLoadBalancerName(loadBalancerName);
		request.setSecurityGroups(securityGroups);
		
		ApplySecurityGroupsToLoadBalancerResult response = elbClient.applySecurityGroupsToLoadBalancer(request);

		printObject(response);
	}
	
	public void createLoadBalancerListeners(String loadBalancerProtocol, String instanceProtocol, Integer instancePort, Integer loadBalancerPort) {
		CreateLoadBalancerListenersRequest request = new CreateLoadBalancerListenersRequest();
		
		List<Listener> listeners = new ArrayList<Listener>();
		Listener listener = new Listener();
		listener.setInstanceProtocol(instanceProtocol);
		listener.setProtocol(loadBalancerProtocol);
		listener.setInstancePort(instancePort);
		listener.setLoadBalancerPort(loadBalancerPort);
        listeners.add(listener);
        
		request.setListeners(listeners);
		
		CreateLoadBalancerListenersResult response = elbClient.createLoadBalancerListeners(request);

		printObject(response);
	}
	
	public void deleteLoadBalancer(String loadBalancerName) {
		DeleteLoadBalancerRequest request = new DeleteLoadBalancerRequest();
		request.setLoadBalancerName(loadBalancerName);
		
		DeleteLoadBalancerResult response = elbClient.deleteLoadBalancer(request);

		printObject(response);
	}
	
	public void describeLoadBalancers(String loadBalancerName) {
		DescribeLoadBalancersRequest request = new DescribeLoadBalancersRequest();

		if(!StringUtils.isNullOrEmpty(loadBalancerName)) {
			request.setLoadBalancerNames(Arrays.asList(loadBalancerName));
		}
		
		DescribeLoadBalancersResult response = elbClient.describeLoadBalancers(request );
		printObject(response);
	}
	
	public void createOrUpdateHealthCheck(String loadBalancerName) {
		HealthCheck healthCheck = new HealthCheck();
		healthCheck.withHealthyThreshold(2);
		healthCheck.withInterval(30);
		healthCheck.withTarget("TCP:80");
		healthCheck.withTimeout(5);
		healthCheck.withUnhealthyThreshold(2);
		
		ConfigureHealthCheckRequest request = new ConfigureHealthCheckRequest();
		request.setHealthCheck(healthCheck);
		request.setLoadBalancerName(loadBalancerName);

		ConfigureHealthCheckResult response = elbClient.configureHealthCheck(request);
		printObject(response);
	}
	
	public void getInstanceHealth(String loadBalancerName, List<String> instanceIds) {
		DescribeInstanceHealthRequest request = new DescribeInstanceHealthRequest();
		request.setLoadBalancerName(loadBalancerName);
		request.setInstances(getELDInstanceList(instanceIds));
		
		DescribeInstanceHealthResult response = elbClient.describeInstanceHealth(request);
		printObject(response);
	}

	public void deleteLoadBalancerListener(String loadBalancerName, Integer loadBalancePort) {
		DeleteLoadBalancerListenersRequest request = new DeleteLoadBalancerListenersRequest();
		request.setLoadBalancerName(loadBalancerName);
		
		request.setLoadBalancerPorts(Arrays.asList(loadBalancePort));
		
		DeleteLoadBalancerListenersResult response = elbClient.deleteLoadBalancerListeners(request);
		printObject(response);
	}
	
	public void registerInstancesToLoadBalancer(String loadBalancerName, List<String> instanceIds) {
		RegisterInstancesWithLoadBalancerRequest request = new RegisterInstancesWithLoadBalancerRequest();
		request.setLoadBalancerName(loadBalancerName);
		request.setInstances(getELDInstanceList(instanceIds));
		
        RegisterInstancesWithLoadBalancerResult response = elbClient.registerInstancesWithLoadBalancer(request);
		printObject(response);
	}
	
	public void deregisterInstancesFromLoadBalancer(String loadBalancerName, List<String> instanceIds) {
		DeregisterInstancesFromLoadBalancerRequest request = new DeregisterInstancesFromLoadBalancerRequest();
		request.setLoadBalancerName(loadBalancerName);
		request.setInstances(getELDInstanceList(instanceIds));
		
		DeregisterInstancesFromLoadBalancerResult response = elbClient.deregisterInstancesFromLoadBalancer(request);
		printObject(response);
	}
	
	public void addTags(String loadBalancerName, List<Tag> tags) {
		AddTagsRequest request = new AddTagsRequest();
		request.setLoadBalancerNames(Arrays.asList(loadBalancerName));
		request.setTags(tags);

		AddTagsResult response = elbClient.addTags(request );
		printObject(response);
	}
	
	public void describeTags(String loadBalancerName) {
		DescribeTagsRequest request = new DescribeTagsRequest();
		request.setLoadBalancerNames(Arrays.asList(loadBalancerName));
		
		DescribeTagsResult response = elbClient.describeTags(request );
		printObject(response);
	}
	
	public void deleteTags(String loadBalancerName, String key) {
		TagKeyOnly tagKeyOnly = new TagKeyOnly();
		tagKeyOnly.setKey(key);
		
		List<TagKeyOnly> tagKeyOnlyList = new ArrayList<TagKeyOnly>();
		tagKeyOnlyList.add(tagKeyOnly );
		
		RemoveTagsRequest request = new RemoveTagsRequest();
		request.setLoadBalancerNames(Arrays.asList(loadBalancerName));
		request.setTags(tagKeyOnlyList);
		
		RemoveTagsResult response = elbClient.removeTags(request);

		printObject(response);
	}
	
	private List<Instance> getELDInstanceList(List<String> instanceIds) {
		
		List<Instance> instanceList = new ArrayList<Instance>();
		
		if(instanceIds!=null && !instanceIds.isEmpty()) {
			for(String instanceId: instanceIds){
				instanceList.add(new Instance(instanceId));
			}
		}
		
		return instanceList;
	}
}
