package com.sunil.gulabani.chapter2.utility;

import java.io.*;

public class FileOperations {
	public void saveFile(String fileName, String content) {
		
		try {
			File file = new File(fileName);

			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fileWriter = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fileWriter);
			bw.write(content);
			bw.close();
			
			System.out.println("File Saved: " + file.getAbsolutePath());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String readFile(String fileName) {
		StringBuilder content = new StringBuilder();
		try (BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName))){
			String line;

			while ((line = bufferedReader.readLine()) != null) {
				content.append(line).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return content.toString();
	}
}