package com.sunil.gulabani.chapter2.volume;

import java.util.List;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.AttachVolumeRequest;
import com.amazonaws.services.ec2.model.AttachVolumeResult;
import com.amazonaws.services.ec2.model.CreateVolumeRequest;
import com.amazonaws.services.ec2.model.CreateVolumeResult;
import com.amazonaws.services.ec2.model.DeleteVolumeRequest;
import com.amazonaws.services.ec2.model.DeleteVolumeResult;
import com.amazonaws.services.ec2.model.DescribeVolumeStatusResult;
import com.amazonaws.services.ec2.model.DescribeVolumesResult;
import com.amazonaws.services.ec2.model.DetachVolumeRequest;
import com.amazonaws.services.ec2.model.DetachVolumeResult;
import com.amazonaws.services.ec2.model.Volume;
import com.amazonaws.services.ec2.model.VolumeStatusItem;
import com.amazonaws.services.ec2.model.VolumeType;
import com.sunil.gulabani.chapter2.core.AWSClientInitializer;

public class EC2VolumeOperations extends AWSClientInitializer {
	private AmazonEC2 amazonEC2Client;
	
	public EC2VolumeOperations() {
		super();
		amazonEC2Client = new AmazonEC2Client(getCredentials(), getClientConfiguration());
		amazonEC2Client.setRegion(region);
	}
	
	public String createVolume(Integer size, VolumeType volumeType) {
		seperator("createVolume");
		
		CreateVolumeRequest request = new CreateVolumeRequest();
		request.setSize(size);
		request.setVolumeType(volumeType);
//		request.setAvailabilityZone(availabilityZone);
		
		CreateVolumeResult response = amazonEC2Client.createVolume(request);
		printObject(response);
		
		return response.getVolume().getVolumeId();
	}
	
	public void attachVolume(String device, String instanceId, String volumeId) {
		seperator("attachVolume");
		
		AttachVolumeRequest request = new AttachVolumeRequest();
		request.setDevice(device);
		request.setInstanceId(instanceId);
		request.setVolumeId(volumeId);
		
		AttachVolumeResult response = amazonEC2Client.attachVolume(request);
		printObject(response);
	}
	
	public void detachVolume(String device, String instanceId, String volumeId) {
		seperator("detachVolume");
		
		DetachVolumeRequest request = new DetachVolumeRequest();
		request.setDevice(device);
		request.setInstanceId(instanceId);
		request.setVolumeId(volumeId);
		
		DetachVolumeResult response = amazonEC2Client.detachVolume(request);
		printObject(response);
	}
	
	public void deleteVolume(String volumeId) {
		seperator("deleteVolume");
		
		DeleteVolumeRequest request = new DeleteVolumeRequest();
		request.setVolumeId(volumeId);
		
		DeleteVolumeResult response = amazonEC2Client.deleteVolume(request);
		printObject(response);
	}
	
	public void describeVolumes() {
		seperator("describeVolumes");
		DescribeVolumesResult response = amazonEC2Client.describeVolumes();
		printObject(response);
	}
	
	/*
	 * http://docs.aws.amazon.com/cli/latest/reference/ec2/describe-volume-status.html
	 */
	public void describeVolumeStatus() {
		seperator("describeVolumeStatus");
		
		DescribeVolumeStatusResult response = amazonEC2Client.describeVolumeStatus();
		printObject(response);
	}
	
	
}
