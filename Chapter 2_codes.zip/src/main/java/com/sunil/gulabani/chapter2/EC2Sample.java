package com.sunil.gulabani.chapter2;

import com.amazonaws.services.ec2.model.InstanceType;
import com.amazonaws.services.ec2.model.Tag;
import com.sunil.gulabani.chapter2.ec2.EC2InstanceOperations;
import com.sunil.gulabani.chapter2.keyPair.KeyPairOperations;
import com.sunil.gulabani.chapter2.securityGroup.SecurityGroupOperations;

public class EC2Sample {
	
	private final static String SECURITY_GROUP_NAME = "EC2CreationViaAWSJavaSDK";
	private final static String SECURITY_GROUP_DESCRIPTION = "EC2 creation via AWS java sdk";
	private final static String KEY_PAIR_NAME = "EC2CreationViaAWSJavaSDK";
	private final static String AMI = "ami-775e4f16";
	private final static InstanceType INSTANCE_TYPE = InstanceType.T2Micro;
	private final static int MIN_INSTANCE_COUNT = 1;
	private final static int MAX_INSTANCE_COUNT = 1;

	public static void main(String[] args) throws InterruptedException {
		SecurityGroupOperations securityGroupOperations = new SecurityGroupOperations();

		String securityGroupId = securityGroupOperations.createSecurityGroup(SECURITY_GROUP_NAME, SECURITY_GROUP_DESCRIPTION);
//		securityGroupOperations.assignSSHConnectionAccessToSecurityGroup(SECURITY_GROUP_NAME);
//		securityGroupOperations.describeSecurityGroups(securityGroupId);
//		securityGroupOperations.deleteSecurityGroupBasedOnGroupName(SECURITY_GROUP_NAME);

//		if(securityGroupId != null) {
//			securityGroupOperations.deleteSecurityGroupBasedOnGroupId(securityGroupId);
//		}
//		securityGroupOperations.describeSecurityGroups(null);

		KeyPairOperations keyPairOperations = new KeyPairOperations();
		keyPairOperations.createKeyPair(KEY_PAIR_NAME);
//		keyPairOperations.describeKeyPairs(null);
//		keyPairOperations.describeKeyPairs(KEY_PAIR_NAME);
//		keyPairOperations.deleteKeyPair(KEY_PAIR_NAME);
//		keyPairOperations.importKeyPair("AWS-JAVA-SDK-IMPORTED-KEY", "C:\\Users\\Dell\\EC2CreationViaAWSCLI.pub");

		EC2InstanceOperations ec2Operations = new EC2InstanceOperations();
		ec2Operations.describeImageIds(AMI);
        String instanceId = ec2Operations.launchInstance(
                AMI,
                INSTANCE_TYPE,
                MIN_INSTANCE_COUNT,
                MAX_INSTANCE_COUNT,
                KEY_PAIR_NAME,
                SECURITY_GROUP_NAME);

        ec2Operations.describeInstanceStatus(instanceId);
/*
        ec2Operations.describeInstances(null);
        ec2Operations.describeInstances(instanceId);

        List<Tag> tags = new ArrayList<Tag>();
		tags.add(createTag("Chapter", "2"));
		tags.add(createTag("Environment", "Production"));

		ec2Operations.assignTagToEC2(instanceId, tags);

		ec2Operations.describeTags(instanceId);

		List<Tag> deleteTags = new ArrayList<Tag>();
		deleteTags.add(createTag("Chapter", "2"));

		ec2Operations.deleteTags(instanceId, deleteTags);

		ec2Operations.stopInstance(instanceId);
		Thread.sleep(300000);
		ec2Operations.startInstance(instanceId);
		Thread.sleep(300000);
		ec2Operations.terminateInstance(instanceId);
		Thread.sleep(300000);
		keyPairOperations.deleteKeyPair(KEY_PAIR_NAME);
		securityGroupOperations.deleteSecurityGroupBasedOnGroupName(SECURITY_GROUP_NAME);*/

    }

	private static Tag createTag(String key, String value) {
		Tag tag = new Tag();
		tag.setKey(key);
		tag.setValue(value);
		return tag;
	}
}
