package com.sunil.gulabani.chapter2.keyPair;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.*;
import com.amazonaws.util.StringUtils;
import com.sunil.gulabani.chapter2.core.AWSClientInitializer;
import com.sunil.gulabani.chapter2.utility.FileOperations;

public class KeyPairOperations extends AWSClientInitializer {

	protected AmazonEC2 amazonEC2Client;
	
	private FileOperations fileOperations;
	
	public KeyPairOperations() {
		super();
		if(!StringUtils.isNullOrEmpty(getClientConfiguration().getProxyHost()))
			amazonEC2Client = new AmazonEC2Client(getCredentials(), getClientConfiguration());
		else
			amazonEC2Client = new AmazonEC2Client(getCredentials());
		amazonEC2Client.setRegion(region);
		
		fileOperations = new FileOperations();
	}
	
	public void createKeyPair(String keyName) {
		seperator("createKeyPair");
		
		CreateKeyPairRequest request = new CreateKeyPairRequest();
		
		request.withKeyName(keyName);
		
		CreateKeyPairResult response = amazonEC2Client.createKeyPair(request);
		
		KeyPair keyPair = response.getKeyPair();
		
		String privateKey = keyPair.getKeyMaterial();
		
		fileOperations.saveFile(keyName + "_keypair.pem", privateKey);
		printObject(response);
	}
	
	public void describeKeyPairs(String keyName) {
		seperator("describeKeyPairs");

		DescribeKeyPairsRequest request = new DescribeKeyPairsRequest();

		if(!StringUtils.isNullOrEmpty(keyName)) {
			List<String> searchCriteria = new ArrayList<String>();
			searchCriteria.add(keyName);
			request.setKeyNames(searchCriteria);
		}
		
		DescribeKeyPairsResult response = amazonEC2Client.describeKeyPairs(request);
		printObject(response);
	}
	
	public void deleteKeyPair(String keyName) {
		seperator("deleteKeyPair");
		
		DeleteKeyPairRequest request = new DeleteKeyPairRequest();
		
		request.setKeyName(keyName);
		
		DeleteKeyPairResult response = amazonEC2Client.deleteKeyPair(request);
		printObject(response);
	}

	public void importKeyPair(String keyName, String publicKeyFilePath) {
		seperator("importKeyPair");

		ImportKeyPairRequest request = new ImportKeyPairRequest();
		request.setKeyName(keyName);
		request.setPublicKeyMaterial(fileOperations.readFile(publicKeyFilePath));

		ImportKeyPairResult response = amazonEC2Client.importKeyPair(request);
		printObject(response);
	}
}
