package com.sunil.gulabani.chapter2.ec2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.*;
import com.amazonaws.util.StringUtils;
import com.sunil.gulabani.chapter2.core.AWSClientInitializer;

public class EC2InstanceOperations extends AWSClientInitializer {
	
	private static final Object PENDING_STATUS = "pending";
	private static final String SPOT_INSTANCE_BID_PRICE = "0.04";
	
	protected AmazonEC2 amazonEC2Client;
	
	public EC2InstanceOperations() {
		super();
		if(!StringUtils.isNullOrEmpty(getClientConfiguration().getProxyHost()))
			amazonEC2Client = new AmazonEC2Client(getCredentials(), getClientConfiguration());
		else
			amazonEC2Client = new AmazonEC2Client(getCredentials());
		amazonEC2Client.setRegion(region);
	}

	public void describeImageIds(String imageId) {
		DescribeImagesRequest request = new DescribeImagesRequest();
		if(!StringUtils.isNullOrEmpty(imageId)) {
			request.withImageIds(imageId);
		}
		DescribeImagesResult response = amazonEC2Client.describeImages(request);
		printObject(response);
	}
	
	public String launchInstance(String ami, InstanceType instanceType, int minInstanceCount, int maxInstanceCount, String keyPairName, String securityGroupName) {
		seperator("launchInstance");
		
		RunInstancesRequest request = new RunInstancesRequest();
		
		request.setImageId(ami);
		request.setInstanceType(instanceType);
		
		request.setKeyName(keyPairName);
		List<String> securityGroups = new ArrayList<String>();
		securityGroups.add(securityGroupName);
		request.setSecurityGroups(securityGroups);
		
		request.setMinCount(minInstanceCount);
		request.setMaxCount(maxInstanceCount);
		
		RunInstancesResult response = amazonEC2Client.runInstances(request);
		
		printObject(response);
		
		return getInstanceId();
	}
	
	public String getInstanceId() {
		seperator("getInstanceId");
		
		String instanceId=null;
		DescribeInstancesResult response = amazonEC2Client.describeInstances();
		for(Reservation reservation: response.getReservations()) {
			List<Instance> instances = reservation.getInstances();
			for (Instance instance : instances) {
				if (instance.getState().getName().equals(PENDING_STATUS)) {
					instanceId = instance.getInstanceId();
					break;
				}
			}
		}
		printObject(response);
		return instanceId;
	}
	
	public void startInstance(String instanceId) {
		seperator("startInstance");
		
		StartInstancesRequest request = new StartInstancesRequest();
		request.setInstanceIds(Arrays.asList(instanceId));
		
		StartInstancesResult response = amazonEC2Client.startInstances(request);
		
		printObject(response);
	}
	
	public void stopInstance (String instanceId) {
		seperator("stopInstance");
		
		StopInstancesRequest request = new StopInstancesRequest();

		request.setInstanceIds(Arrays.asList(instanceId));
		
		StopInstancesResult response = amazonEC2Client.stopInstances(request);
		
		printObject(response);
	}
	
	public void terminateInstance (String instanceId) {
		seperator("terminateInstance");
		
		TerminateInstancesRequest request = new TerminateInstancesRequest();
		request.setInstanceIds(Arrays.asList(instanceId));
		
		TerminateInstancesResult response = amazonEC2Client.terminateInstances(request);
		
		printObject(response);
	}
	
	public List<String> describeInstances(String instanceId) {
		seperator("listInstances");
		
		List<String> instanceIdList = new ArrayList<String>();

		DescribeInstancesRequest request = new DescribeInstancesRequest();

		if(!StringUtils.isNullOrEmpty(instanceId)) {
			request.setInstanceIds(Arrays.asList(instanceId));
		}

		DescribeInstancesResult response = amazonEC2Client.describeInstances(request);
		
		if(response!=null && response.getReservations()!=null && !response.getReservations().isEmpty()) {
			for(Reservation reservation: response.getReservations()) {
				List<Instance> instances = reservation.getInstances();
				if(instances!=null && !instances.isEmpty()) {
					for(Instance instance: instances) {
						instanceIdList.add(instance.getInstanceId());
					}
				}
			}
		}
		printObject(response);
		return instanceIdList;
	}


	public void describeInstanceStatus(String instanceId) {
		seperator("describeInstanceStatus");

		DescribeInstanceStatusRequest request = new DescribeInstanceStatusRequest();
		request.setInstanceIds(Arrays.asList(instanceId));

		DescribeInstanceStatusResult response = amazonEC2Client.describeInstanceStatus(request);

		printObject(response);
	}

	public String createSpotInstance(
			String ami, 
			InstanceType instanceType, 
			String securityGroupName, 
			Integer instanceCount, 
			String keyPairName) {
		
		seperator("createSpotInstance");
		
		RequestSpotInstancesRequest request = new RequestSpotInstancesRequest();
		request.setSpotPrice(SPOT_INSTANCE_BID_PRICE);
		request.setInstanceCount(instanceCount);

		LaunchSpecification launchSpecification = createLaunchSpecification(ami, instanceType, securityGroupName, keyPairName);
		
		request.setLaunchSpecification(launchSpecification);
		
		RequestSpotInstancesResult response = amazonEC2Client.requestSpotInstances(request);
		
		printObject(response);
		
		return getSpotInstanceId();
	}
	
	private LaunchSpecification createLaunchSpecification(
			String ami, 
			InstanceType instanceType, 
			String securityGroupName, 
			String keyPairName) {
		LaunchSpecification launchSpecification = new LaunchSpecification();
		
		launchSpecification.setImageId(ami);
		launchSpecification.setInstanceType(instanceType);
		
		List<String> securityGroupList = new ArrayList<String>();
		securityGroupList.add(securityGroupName);
		launchSpecification.setSecurityGroups(securityGroupList);
		
		launchSpecification.setKeyName(keyPairName);
		
		return launchSpecification;
	}
	
	public String getSpotInstanceId() {
		seperator("getInstanceId");
		
		String instanceId=null;
		DescribeSpotInstanceRequestsResult response = amazonEC2Client.describeSpotInstanceRequests();
		
		if(response!=null && response.getSpotInstanceRequests()!=null && !response.getSpotInstanceRequests().isEmpty()) {
			List<SpotInstanceRequest> spotInstances = response.getSpotInstanceRequests();
			
			for (SpotInstanceRequest instance : spotInstances) {
				if (instance.getState().equals(PENDING_STATUS)) {
					instanceId = instance.getInstanceId();
					break;
				}
			}
		}
		printObject(response);
		return instanceId;
	}
	
	public void listAllSpotInstances() {
		seperator("listAllSpotInstances");
		
		DescribeSpotInstanceRequestsResult response = amazonEC2Client.describeSpotInstanceRequests();
		
		printObject(response);
	}
	
	public void cancelSpotInstance(String instanceId) {
		seperator("cancelSpotInstance");
		
		List<String> spotInstanceRequestIds = new ArrayList<String>();
		spotInstanceRequestIds.add(instanceId);
		
		CancelSpotInstanceRequestsRequest request = new CancelSpotInstanceRequestsRequest();
		request.setSpotInstanceRequestIds(spotInstanceRequestIds);
		
		CancelSpotInstanceRequestsResult response = amazonEC2Client.cancelSpotInstanceRequests(request);
		
		printObject(response);
	}
	
	public void terminateSpotInstance(String instanceId) {
		seperator("terminateSpotInstance");
		
		List<String> spotInstanceRequestIds = new ArrayList<String>();
		spotInstanceRequestIds.add(instanceId);
		
		TerminateInstancesRequest request = new TerminateInstancesRequest();
		request.setInstanceIds(spotInstanceRequestIds);
		
		TerminateInstancesResult response = amazonEC2Client.terminateInstances(request);
		
		printObject(response);
	}
	
	public void assignTagToEC2(String instanceId, List<Tag> tags) {
		seperator("assignTagToEC2");

		CreateTagsRequest request = new CreateTagsRequest();
		request.setResources(Arrays.asList(instanceId));
		request.setTags(tags);

		CreateTagsResult response = amazonEC2Client.createTags(request);
		printObject(response);
	}
	
	public void deleteTags(String instanceId, List<Tag> tags) {
		seperator("deleteTags");
		
		DeleteTagsRequest request = new DeleteTagsRequest();
		request.setResources(Arrays.asList(instanceId));
		request.setTags(tags);

		DeleteTagsResult response = amazonEC2Client.deleteTags(request);
		printObject(response);
	}
	
	public void describeTags(String instanceId) {
		seperator("listTags");
		DescribeTagsRequest request = new DescribeTagsRequest();

		Filter filter = new Filter("resource-id", Arrays.asList(instanceId));
		request.setFilters(Arrays.asList(filter));

		DescribeTagsResult response = amazonEC2Client.describeTags(request);
		printObject(response);
	}
}