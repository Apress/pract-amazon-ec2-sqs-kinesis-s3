package com.sunil.gulabani.chapter5;

import com.amazonaws.regions.*;
import com.amazonaws.regions.Region;
import com.amazonaws.services.rds.model.Timezone;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.iterable.S3Objects;
import com.amazonaws.services.s3.iterable.S3Versions;
import com.amazonaws.services.s3.model.*;
import com.amazonaws.util.StringUtils;
import com.sunil.gulabani.chapter5.core.AWSClientInitializer;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;

public class S3Operations extends AWSClientInitializer {

	private static final String NO_RESPONSE = "NO RESPONSE";
	private AmazonS3Client amazonS3Client;
	private String awsUserAccountId;
	
	public S3Operations(String awsUserAccountId, Regions regions) {
		super();
		if(regions != null)
			region = Region.getRegion(regions);

		if(!StringUtils.isNullOrEmpty(getClientConfiguration().getProxyHost())) {
			amazonS3Client = new AmazonS3Client(getCredentials(), getClientConfiguration());
		} else {
			amazonS3Client = new AmazonS3Client(getCredentials());
		}
		amazonS3Client.setRegion(region);

		this.awsUserAccountId = awsUserAccountId;
	}

	public void createBucket(String bucketName) {
		Bucket bucket = amazonS3Client.createBucket(bucketName);
		printObject(bucket, "createBucket");
	}

	public void createBucket(String bucketName, AccessControlList accessControlList, CannedAccessControlList cannedAcl) {
		CreateBucketRequest request = new CreateBucketRequest(bucketName);
		request.setRegion(region.getName());

		if(accessControlList != null) {
			request.setAccessControlList(accessControlList);
		}

		if(cannedAcl != null) {
			request.setCannedAcl(cannedAcl);
		}

		Bucket bucket = amazonS3Client.createBucket(request);
		printObject(bucket, "createBucket");
	}

	public void listBuckets() {
		List<Bucket> response = amazonS3Client.listBuckets();
		printObject(response, "listBuckets");
	}

	public AccessControlList createAccessControlList(String awsMemberCanonicalId, String emailId) {
		AccessControlList accessControlList = new AccessControlList();

		accessControlList.grantPermission(GroupGrantee.AllUsers, Permission.Read);
		accessControlList.grantPermission(GroupGrantee.LogDelivery, Permission.ReadAcp);
		accessControlList.grantPermission(GroupGrantee.LogDelivery, Permission.Write);

		CanonicalGrantee canonicalGrantee = new CanonicalGrantee(awsMemberCanonicalId);
		accessControlList.grantPermission(canonicalGrantee, Permission.FullControl);

		EmailAddressGrantee emailAddressGrantee = new EmailAddressGrantee(emailId);
		accessControlList.grantPermission(emailAddressGrantee, Permission.Write);

		Owner owner = new Owner();
		owner.setDisplayName("sunil.gulabani2@gmail.com");
		owner.setId(awsMemberCanonicalId);

		accessControlList.setOwner(owner);

		return accessControlList;
	}

	public void setBucketAcl(String bucketName, String awsMemberCanonicalId, Grantee grantee, Permission permission) {
		AccessControlList acl = new AccessControlList();
		acl.grantPermission(grantee, permission);

		Owner owner = new Owner();
		owner.setDisplayName("sunil.gulabani2@gmail.com");
		owner.setId(awsMemberCanonicalId);
		acl.setOwner(owner);

		amazonS3Client.setBucketAcl(bucketName, acl);

		printObject(NO_RESPONSE, "setBucketAcl");
	}

	public void getBucketAcl(String bucketName) {
		AccessControlList response = amazonS3Client.getBucketAcl(bucketName);
		printObject(response, "getBucketAcl");
	}

	public void setBucketLoggingConfiguration(String bucketName, String destinationBucketName, String logFilePrefix) {
		BucketLoggingConfiguration loggingConfiguration = new BucketLoggingConfiguration();
		loggingConfiguration.setDestinationBucketName(destinationBucketName);
		loggingConfiguration.setLogFilePrefix(logFilePrefix);

		SetBucketLoggingConfigurationRequest request = new SetBucketLoggingConfigurationRequest(bucketName, loggingConfiguration);

		amazonS3Client.setBucketLoggingConfiguration(request);
		printObject(NO_RESPONSE, "setBucketLoggingConfiguration");
	}

	public void getBucketLoggingConfiguration(String bucketName) {
		BucketLoggingConfiguration response = amazonS3Client.getBucketLoggingConfiguration(bucketName);
		printObject(response, "getBucketLoggingConfiguration");
	}

	public void setBucketWebsiteConfiguration(String bucketName, String indexDocument, String errorDocument) {
		BucketWebsiteConfiguration configuration = new BucketWebsiteConfiguration();
		configuration.setIndexDocumentSuffix(indexDocument);
		configuration.setErrorDocument(errorDocument);
		amazonS3Client.setBucketWebsiteConfiguration(bucketName, configuration);
		printObject(NO_RESPONSE, "setBucketWebsiteConfiguration");
	}

	public void setBucketWebsiteConfiguration(String bucketName, String hostName) {
		BucketWebsiteConfiguration configuration = new BucketWebsiteConfiguration();

		RedirectRule redirectRule = new RedirectRule();
		redirectRule.setHostName(hostName);
		redirectRule.setProtocol("http");
		configuration.setRedirectAllRequestsTo(redirectRule);
		amazonS3Client.setBucketWebsiteConfiguration(bucketName, configuration);

		printObject(NO_RESPONSE, "setBucketWebsiteConfiguration");
	}

	public void getBucketWebsiteConfiguration(String bucketName) {
		BucketWebsiteConfiguration response = amazonS3Client.getBucketWebsiteConfiguration(bucketName);
		printObject(response, "getBucketWebsiteConfiguration");
	}

	public void setBucketNotificationConfiguration_SQS(String bucketName, S3Event s3Event, String queueARN, String prefixValue, String suffixValue) {
		BucketNotificationConfiguration bucketNotificationConfiguration = getBucketNotificationConfiguration(bucketName);

		QueueConfiguration queueConfiguration = new QueueConfiguration();
		queueConfiguration.setQueueARN(queueARN);
		queueConfiguration.addEvent(s3Event);
		queueConfiguration.setFilter(createFilters(prefixValue, suffixValue));
		bucketNotificationConfiguration.addConfiguration("SQSS3Notification", queueConfiguration);
		amazonS3Client.setBucketNotificationConfiguration(bucketName, bucketNotificationConfiguration);

		printObject(NO_RESPONSE, "setBucketNotificationConfiguration_SQS");
	}

	public void setBucketNotificationConfiguration_SNS(String bucketName, S3Event s3Event, String topicARN, String prefixValue, String suffixValue) {
		BucketNotificationConfiguration bucketNotificationConfiguration = getBucketNotificationConfiguration(bucketName);

		TopicConfiguration topicConfiguration = new TopicConfiguration();
		topicConfiguration.addEvent(s3Event);
		topicConfiguration.setTopicARN(topicARN);
		topicConfiguration.setFilter(createFilters(prefixValue, suffixValue));
		bucketNotificationConfiguration.addConfiguration("SNSS3Notification", topicConfiguration);

		amazonS3Client.setBucketNotificationConfiguration(bucketName, bucketNotificationConfiguration);

		printObject(NO_RESPONSE, "setBucketNotificationConfiguration_SNS");
	}

	public void setBucketNotificationConfiguration_Lambda(String bucketName, S3Event s3Event, String lambdaFunctionARN, String prefixValue, String suffixValue) {
		BucketNotificationConfiguration bucketNotificationConfiguration = getBucketNotificationConfiguration(bucketName);

		LambdaConfiguration lambdaConfiguration = new LambdaConfiguration(lambdaFunctionARN);
		lambdaConfiguration.addEvent(s3Event);
		lambdaConfiguration.setFilter(createFilters(prefixValue, suffixValue));
		bucketNotificationConfiguration.addConfiguration("LambdaFunctionS3Notification", lambdaConfiguration);

		amazonS3Client.setBucketNotificationConfiguration(bucketName, bucketNotificationConfiguration);

		printObject(NO_RESPONSE, "setBucketNotificationConfiguration_Lambda");
	}

	private Filter createFilters(String prefixValue, String suffixValue) {
		Filter filter = null;

		if(!StringUtils.isNullOrEmpty(prefixValue) && !StringUtils.isNullOrEmpty(suffixValue)) {
			List<FilterRule> filterRules = new ArrayList<>();

			if(!StringUtils.isNullOrEmpty(prefixValue)) {
				FilterRule prefixFilterRule = new FilterRule();
				prefixFilterRule.setName("prefix");
				prefixFilterRule.setValue(prefixValue);
				filterRules.add(prefixFilterRule);
			}

			if(!StringUtils.isNullOrEmpty(suffixValue)) {
				FilterRule suffixFilterRule = new FilterRule();
				suffixFilterRule.setName("suffix");
				suffixFilterRule.setValue(suffixValue);
				filterRules.add(suffixFilterRule);
			}

			S3KeyFilter s3KeyFilter = new S3KeyFilter();
			s3KeyFilter.setFilterRules(filterRules);

			filter = new Filter();
			filter.setS3KeyFilter(s3KeyFilter);
		}
		return filter;
	}

	public BucketNotificationConfiguration getBucketNotificationConfiguration(String bucketName) {
		BucketNotificationConfiguration response = amazonS3Client.getBucketNotificationConfiguration(bucketName);
		printObject(response, "getBucketNotificationConfiguration");
		return response;
	}

	public void setBucketVersioningConfiguration(String bucketName, String status) {
		BucketVersioningConfiguration configuration = new BucketVersioningConfiguration();
		configuration.setStatus(status);
		SetBucketVersioningConfigurationRequest request = new SetBucketVersioningConfigurationRequest(bucketName, configuration);
		amazonS3Client.setBucketVersioningConfiguration(request);
		printObject(NO_RESPONSE, "setBucketVersioningConfiguration");
	}

	public void getBucketVersioningConfiguration(String bucketName) {
		BucketVersioningConfiguration response = amazonS3Client.getBucketVersioningConfiguration(bucketName);
		printObject(response, "getBucketVersioningConfiguration");
	}

	public void setBucketLifecycleConfiguration(String bucketName) {
		BucketLifecycleConfiguration configuration = new BucketLifecycleConfiguration();
		List<BucketLifecycleConfiguration.Rule> rules = new ArrayList<>();

		rules.add(expirationRuleWithDate());
		rules.add(expirationRuleWithDays());
		rules.add(moveOldObjectsToGlacierRule());
		rules.add(nonCurrentVersionTransitionsAndExpirationRule());
		rules.add(abortIncompleteMultipartUploadRule());
		configuration.setRules(rules);
		SetBucketLifecycleConfigurationRequest request = new SetBucketLifecycleConfigurationRequest(bucketName, configuration);
		amazonS3Client.setBucketLifecycleConfiguration(request);

		printObject(NO_RESPONSE, "setBucketLifecycleConfiguration");
	}

	public void getBucketLifecycleConfiguration(String bucketName) {
		BucketLifecycleConfiguration response = amazonS3Client.getBucketLifecycleConfiguration(bucketName);
		printObject(response, "getBucketLifecycleConfiguration");
	}

	public void deleteBucketLifecycleConfiguration(String bucketName) {
		amazonS3Client.deleteBucketLifecycleConfiguration(bucketName);
		printObject(NO_RESPONSE, "deleteBucketLifecycleConfiguration");
	}

	private BucketLifecycleConfiguration.Rule expirationRuleWithDate() {
		BucketLifecycleConfiguration.Rule rule = new BucketLifecycleConfiguration.Rule();
		rule.setId("Expiration Action with Date");
		rule.setPrefix("chapter1");
		rule.setStatus(BucketLifecycleConfiguration.ENABLED);
		rule.setExpirationDate(getDate());
		return rule;
	}

	private BucketLifecycleConfiguration.Rule expirationRuleWithDays() {
		BucketLifecycleConfiguration.Rule rule = new BucketLifecycleConfiguration.Rule();
		rule.setId("Expiration Action with Days");
		rule.setPrefix("chapter2");
		rule.setStatus(BucketLifecycleConfiguration.ENABLED);
		rule.setExpirationInDays(30);
		return rule;
	}

	private BucketLifecycleConfiguration.Rule moveOldObjectsToGlacierRule() {
		BucketLifecycleConfiguration.Rule rule = new BucketLifecycleConfiguration.Rule();
		rule.setId("Move old objects to Glacier Action");
		rule.setPrefix("chapter3");
		rule.setStatus(BucketLifecycleConfiguration.ENABLED);

		List<BucketLifecycleConfiguration.Transition> transitionList = new ArrayList<>();

		BucketLifecycleConfiguration.Transition transition = new BucketLifecycleConfiguration.Transition();
		transition.setDate(getDate());
		transition.setStorageClass(StorageClass.Glacier);
		transitionList.add(transition);
		rule.setTransitions(transitionList);

		return rule;
	}

	private Date getDate() {
		TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
		Calendar gmt = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		gmt.set(Calendar.HOUR_OF_DAY, 0);
		gmt.set(Calendar.MINUTE, 0);
		gmt.set(Calendar.SECOND, 0);
		gmt.set(Calendar.MILLISECOND, 0);
		long millis = gmt.getTimeInMillis();
		return new Date(millis);
	}

	private BucketLifecycleConfiguration.Rule nonCurrentVersionTransitionsAndExpirationRule() {
		BucketLifecycleConfiguration.Rule rule = new BucketLifecycleConfiguration.Rule();
		rule.setId("Non-Current Versioned Object Actions");
		rule.setPrefix("chapter4");
		rule.setStatus(BucketLifecycleConfiguration.ENABLED);

		BucketLifecycleConfiguration.NoncurrentVersionTransition nonCurrentVersionTransition = new BucketLifecycleConfiguration.NoncurrentVersionTransition();
		nonCurrentVersionTransition.setDays(30);
		nonCurrentVersionTransition.setStorageClass(StorageClass.StandardInfrequentAccess);

		List<BucketLifecycleConfiguration.NoncurrentVersionTransition> nonCurrentVersionTransitionList = new ArrayList<>();
		nonCurrentVersionTransitionList.add(nonCurrentVersionTransition);
		rule.setNoncurrentVersionTransitions(nonCurrentVersionTransitionList);
		rule.setNoncurrentVersionExpirationInDays(40);
		return rule;
	}

	private BucketLifecycleConfiguration.Rule abortIncompleteMultipartUploadRule() {
		BucketLifecycleConfiguration.Rule rule = new BucketLifecycleConfiguration.Rule();
		rule.setId("Abort Incomplete Multipart Action");
		rule.setPrefix("chapter5");
		rule.setStatus(BucketLifecycleConfiguration.ENABLED);
		AbortIncompleteMultipartUpload abortIncompleteMultipartUpload = new AbortIncompleteMultipartUpload();
		abortIncompleteMultipartUpload.setDaysAfterInitiation(1);
		rule.setAbortIncompleteMultipartUpload(abortIncompleteMultipartUpload);
		return rule;
	}

	public void setBucketReplicationConfiguration(String bucketName, String roleARN, String destinationBucketARN) {
		BucketReplicationConfiguration configuration = new BucketReplicationConfiguration();
		configuration.setRoleARN(roleARN);

		ReplicationDestinationConfig destination = new ReplicationDestinationConfig();
		destination.setBucketARN(destinationBucketARN);
		destination.setStorageClass(StorageClass.Standard);

		ReplicationRule replicationRule = new ReplicationRule();
		replicationRule.setPrefix("");
		replicationRule.setStatus(ReplicationRuleStatus.Enabled);
		replicationRule.setDestinationConfig(destination);

		Map<String, ReplicationRule> rules = new HashMap<>();
		rules.put("S3 bucket replication", replicationRule);
		configuration.setRules(rules);
		amazonS3Client.setBucketReplicationConfiguration(bucketName, configuration);

		printObject(NO_RESPONSE, "setBucketReplicationConfiguration");
	}

	public void getBucketReplicationConfiguration(String bucketName) {
		BucketReplicationConfiguration response = amazonS3Client.getBucketReplicationConfiguration(bucketName);
		printObject(response, "getBucketReplicationConfiguration");
	}

	public void deleteBucketReplicationConfiguration(String bucketName) {
		amazonS3Client.deleteBucketReplicationConfiguration(bucketName);
		printObject(NO_RESPONSE, "deleteBucketReplicationConfiguration");
	}

	public void setBucketTaggingConfiguration(String bucketName) {
		BucketTaggingConfiguration configuration = new BucketTaggingConfiguration();

		TagSet tagSet1 = new TagSet();
		tagSet1.setTag("Chapter", "5");
		tagSet1.setTag("Name", "AWSS3");

		List<TagSet> tagSets = new ArrayList<>();
		tagSets.add(tagSet1);
		configuration.setTagSets(tagSets);
		amazonS3Client.setBucketTaggingConfiguration(bucketName, configuration);

		printObject(NO_RESPONSE, "setBucketTaggingConfiguration");
	}

	public void getBucketTaggingConfiguration(String bucketName) {
		BucketTaggingConfiguration response = amazonS3Client.getBucketTaggingConfiguration(bucketName);
		printObject(response, "getBucketTaggingConfiguration");
	}

	public void enableRequesterPays(String bucketName) {
		amazonS3Client.enableRequesterPays(bucketName);
		printObject(NO_RESPONSE, "enableRequesterPays");
	}

	public void isRequesterPaysEnabled(String bucketName) {
		boolean isRequesterPaysEnabled = amazonS3Client.isRequesterPaysEnabled(bucketName);
		printObject(isRequesterPaysEnabled, "isRequesterPaysEnabled");
	}

	public void disableRequesterPays(String bucketName) {
		amazonS3Client.disableRequesterPays(bucketName);
		printObject(NO_RESPONSE, "disableRequesterPays");
	}

	public void setBucketAccelerateConfiguration(String bucketName, BucketAccelerateStatus bucketAccelerateStatus) {
		BucketAccelerateConfiguration configuration = new BucketAccelerateConfiguration(bucketAccelerateStatus);

		amazonS3Client.setBucketAccelerateConfiguration(bucketName, configuration);

		printObject(NO_RESPONSE, "setBucketAccelerateConfiguration");
	}

	public void getBucketAccelerateConfiguration(String bucketName) {
		BucketAccelerateConfiguration response = amazonS3Client.getBucketAccelerateConfiguration(bucketName);
		printObject(response, "getBucketAccelerateConfiguration");
	}

	public void deleteObjects(String bucketName) {
		S3Objects s3ObjectSummaries = S3Objects.inBucket(amazonS3Client, bucketName);
		s3ObjectSummaries.forEach(objectSummary -> {
			deleteObject(bucketName, objectSummary.getKey());
		});
		printObject(NO_RESPONSE, "deleteObjects");
	}

	public void deleteBucket(String bucketName) {
		for (S3VersionSummary version : S3Versions.inBucket(amazonS3Client, bucketName)) {
			String key = version.getKey();
			String versionId = version.getVersionId();
			amazonS3Client.deleteVersion(bucketName, key, versionId);
		}

		//		amazonS3Client.deleteBucket(bucketName);
		DeleteBucketRequest request = new DeleteBucketRequest(bucketName);

		amazonS3Client.deleteBucket(request);

		printObject(NO_RESPONSE,"deleteBucket");
	}

	public void createFolder(String bucketName, String folderName) {
		// create meta-data for your folder and set content-length to 0
		ObjectMetadata metadata = new ObjectMetadata();
		metadata.setContentLength(0);

		// create empty content
		InputStream emptyContent = new ByteArrayInputStream(new byte[0]);

		// create a PutObjectRequest passing the folder name suffixed by /
		PutObjectRequest request = new PutObjectRequest(bucketName, folderName + "/", emptyContent, metadata);
		PutObjectResult response = amazonS3Client.putObject(request);
		printObject(response, "createFolder");
	}

	public void deleteFolder(String bucketName, String folderName) {
		DeleteObjectRequest request = new DeleteObjectRequest(bucketName, folderName + "/");
		amazonS3Client.deleteObject(request);
		printObject(NO_RESPONSE, "deleteFolder");
	}

	public void listObjects(String bucketName) {
		ObjectListing response = amazonS3Client.listObjects(bucketName);
		printObject(response, "listObjects");
	}

	public void putObject(String bucketName, String keyName, File file) throws IOException {
		PutObjectRequest request = new PutObjectRequest(bucketName, keyName, file);
		PutObjectResult response = amazonS3Client.putObject(request);
		printObject(response, "putObject");
	}

	public void deleteObject(String bucketName, String keyName) {
		DeleteObjectRequest request = new DeleteObjectRequest(bucketName, keyName);
		amazonS3Client.deleteObject(request);
		printObject(NO_RESPONSE, "deleteObject");
	}
}
