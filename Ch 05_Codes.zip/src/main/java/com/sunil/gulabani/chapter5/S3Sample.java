package com.sunil.gulabani.chapter5;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.model.*;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;

public class S3Sample {
	private static final String AWS_ACCOUNT_ID = "AWS_ACCOUNT_ID";
	private static final String AWS_CANONICAL_ID = "AWS_CANONICAL_ID";
	public static final String BUCKET_NAME = "chapter5-s3sdk-bucket";
	public static final String BUCKET_NAME_2 = "chapter5-s3sdk-bucket-new";
	public static final String BUCKET_NAME_BACKUP = "chapter5-s3cli-buckets-backups";
	private static final String DESTINATION_BUCKET_ARN = "arn:aws:s3:::" + BUCKET_NAME_BACKUP;
	public static final String EMAIL_ID = "sunil.gulabani1@gmail.com";
	public static final String LOG_FILE_PREFIX = "logs";
	public static final String SNS_TOPIC_ARN = "arn:aws:sns:us-west-2:AWS_ACCOUNT_ID:objectCreatedSNSTopic";
	public static final String SQS_ARN = "arn:aws:sqs:us-west-2:AWS_ACCOUNT_ID:objectRemovedQueue";
	public static final String LAMBDA_TOPIC_ARN = "arn:aws:lambda:us-west-2:AWS_ACCOUNT_ID:function:reducedRedundancyLostObjectLambda";
	private static final String ROLE_ARN = "arn:aws:iam::AWS_ACCOUNT_ID:role/s3BucketReplicationRole";

	private static final String FOLDER_NAME = "apress";

	public static void main(String[] args) throws IOException, InterruptedException {

		S3Operations s3Operations = new S3Operations(AWS_ACCOUNT_ID, Regions.US_WEST_2);
		S3Operations s3Operations2 = new S3Operations(AWS_ACCOUNT_ID, Regions.AP_SOUTHEAST_1);

		try {
			s3Operations.setBucketAcl(BUCKET_NAME, AWS_CANONICAL_ID, GroupGrantee.AllUsers, Permission.FullControl);
			s3Operations.deleteBucket(BUCKET_NAME);
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			s3Operations.setBucketAcl(BUCKET_NAME_2, AWS_CANONICAL_ID, GroupGrantee.AllUsers, Permission.FullControl);
			s3Operations.deleteBucket(BUCKET_NAME_2);
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			s3Operations2.setBucketAcl(BUCKET_NAME_BACKUP, AWS_CANONICAL_ID, GroupGrantee.AllUsers, Permission.FullControl);
			s3Operations2.deleteBucket(BUCKET_NAME_BACKUP);
		} catch (Exception e) {
			e.printStackTrace();
		}

		s3Operations.createBucket(BUCKET_NAME);
		s3Operations.listBuckets();
		AccessControlList accessControlList = s3Operations.createAccessControlList(AWS_CANONICAL_ID, EMAIL_ID);
		s3Operations.createBucket(
				BUCKET_NAME_2,
				accessControlList,
				CannedAccessControlList.BucketOwnerFullControl);
		s3Operations.listBuckets();

		Thread.sleep(20000);

		s3Operations.setBucketAcl(BUCKET_NAME, AWS_CANONICAL_ID, GroupGrantee.AllUsers, Permission.Read);
		s3Operations.getBucketAcl(BUCKET_NAME);

		s3Operations.setBucketWebsiteConfiguration(BUCKET_NAME, "sunilgulabani.com");
		s3Operations.getBucketWebsiteConfiguration(BUCKET_NAME);

		s3Operations.setBucketWebsiteConfiguration(BUCKET_NAME, "index.html", "error.html");
		s3Operations.getBucketWebsiteConfiguration(BUCKET_NAME);

		s3Operations.setBucketLoggingConfiguration(BUCKET_NAME, BUCKET_NAME_2, LOG_FILE_PREFIX);
		s3Operations.getBucketLoggingConfiguration(BUCKET_NAME);

		s3Operations.setBucketNotificationConfiguration_SNS(BUCKET_NAME, S3Event.ObjectCreated, SNS_TOPIC_ARN, null, null);
		s3Operations.setBucketNotificationConfiguration_SQS(BUCKET_NAME, S3Event.ObjectRemoved, SQS_ARN, null, null);
		s3Operations.setBucketNotificationConfiguration_Lambda(BUCKET_NAME, S3Event.ReducedRedundancyLostObject, LAMBDA_TOPIC_ARN, "chapter5", "log");
		s3Operations.getBucketNotificationConfiguration(BUCKET_NAME);

		s3Operations.setBucketVersioningConfiguration(BUCKET_NAME, BucketVersioningConfiguration.ENABLED);
		s3Operations.getBucketVersioningConfiguration(BUCKET_NAME);

		s3Operations.setBucketVersioningConfiguration(BUCKET_NAME, BucketVersioningConfiguration.SUSPENDED);
		s3Operations.getBucketVersioningConfiguration(BUCKET_NAME);

		s3Operations.setBucketLifecycleConfiguration(BUCKET_NAME);
		s3Operations.getBucketLifecycleConfiguration(BUCKET_NAME);
		s3Operations.deleteBucketLifecycleConfiguration(BUCKET_NAME);

		s3Operations2.createBucket(BUCKET_NAME_BACKUP);
		s3Operations.setBucketVersioningConfiguration(BUCKET_NAME, BucketVersioningConfiguration.ENABLED);
		s3Operations2.setBucketVersioningConfiguration(BUCKET_NAME_BACKUP, BucketVersioningConfiguration.ENABLED);
		s3Operations.setBucketReplicationConfiguration(BUCKET_NAME, ROLE_ARN, DESTINATION_BUCKET_ARN);
		s3Operations.getBucketReplicationConfiguration(BUCKET_NAME);
		s3Operations.deleteBucketReplicationConfiguration(BUCKET_NAME);
		s3Operations.setBucketVersioningConfiguration(BUCKET_NAME, BucketVersioningConfiguration.SUSPENDED);
		s3Operations2.setBucketVersioningConfiguration(BUCKET_NAME_BACKUP, BucketVersioningConfiguration.SUSPENDED);

		s3Operations.setBucketTaggingConfiguration(BUCKET_NAME);
		s3Operations.getBucketTaggingConfiguration(BUCKET_NAME);

		s3Operations.enableRequesterPays(BUCKET_NAME);
		s3Operations.isRequesterPaysEnabled(BUCKET_NAME);

		s3Operations.disableRequesterPays(BUCKET_NAME);
		s3Operations.isRequesterPaysEnabled(BUCKET_NAME);

		s3Operations.setBucketAccelerateConfiguration(BUCKET_NAME, BucketAccelerateStatus.Enabled);
		s3Operations.getBucketAccelerateConfiguration(BUCKET_NAME);

		s3Operations.setBucketAccelerateConfiguration(BUCKET_NAME, BucketAccelerateStatus.Suspended);
		s3Operations.getBucketAccelerateConfiguration(BUCKET_NAME);

		s3Operations.createFolder(BUCKET_NAME, FOLDER_NAME);
		s3Operations.listObjects(BUCKET_NAME);

		s3Operations.deleteFolder(BUCKET_NAME, FOLDER_NAME);
		s3Operations.listObjects(BUCKET_NAME);

		Path tempFile = Files.createTempFile("chapter", ".tmp");
		List<String> lines = Arrays.asList("Hello World!!!", "AWS S3");
		Files.write(tempFile, lines, Charset.defaultCharset(), StandardOpenOption.WRITE);
		s3Operations.putObject(BUCKET_NAME,  "chapter.txt", tempFile.toFile());
		s3Operations.listObjects(BUCKET_NAME);

		s3Operations.listObjects(BUCKET_NAME);
		s3Operations.deleteObject(BUCKET_NAME, "chapter.txt");
		s3Operations.listObjects(BUCKET_NAME);

		s3Operations.putObject(BUCKET_NAME,  "chapter1.txt", tempFile.toFile());
		s3Operations.putObject(BUCKET_NAME,  "chapter2.txt", tempFile.toFile());
		s3Operations.putObject(BUCKET_NAME,  "chapter3.txt", tempFile.toFile());
		s3Operations.putObject(BUCKET_NAME,  "chapter4.txt", tempFile.toFile());
		s3Operations.putObject(BUCKET_NAME,  "chapter5.txt", tempFile.toFile());
		s3Operations.putObject(BUCKET_NAME,  "chapter6.txt", tempFile.toFile());
		s3Operations.listObjects(BUCKET_NAME);
		s3Operations.deleteObjects(BUCKET_NAME); // empty bucket
		s3Operations.listObjects(BUCKET_NAME);

		Thread.sleep(5000);

		s3Operations.setBucketAcl(BUCKET_NAME, AWS_CANONICAL_ID, GroupGrantee.AllUsers, Permission.FullControl);
		s3Operations.deleteBucket(BUCKET_NAME);
		s3Operations.setBucketAcl(BUCKET_NAME_2, AWS_CANONICAL_ID, GroupGrantee.AllUsers, Permission.FullControl);
		s3Operations.deleteBucket(BUCKET_NAME_2);

		s3Operations2.setBucketAcl(BUCKET_NAME_BACKUP, AWS_CANONICAL_ID, GroupGrantee.AllUsers, Permission.FullControl);
		s3Operations2.deleteBucket(BUCKET_NAME_BACKUP);
		s3Operations.listBuckets();
    }
}